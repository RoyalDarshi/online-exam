package controllers

import (
	"exam-backend/database"
	"exam-backend/models"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func CreateExam(c *gin.Context) {
	var exam models.Exam
	if err := c.ShouldBindJSON(&exam); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	userIDStr, _ := c.Get("user_id")
	userID, _ := uuid.Parse(userIDStr.(string))
	exam.CreatedByID = userID

	if err := database.DB.Create(&exam).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, exam)
}

func GetExams(c *gin.Context) {
	var exams []models.Exam
	role, _ := c.Get("role")

	query := database.DB
	if role == "student" {
		query = query.Where("is_active = ?", true)
	}
	query.Order("created_at desc").Find(&exams)
	c.JSON(http.StatusOK, exams)
}

func GetExamDetails(c *gin.Context) {
	id := c.Param("id")
	var exam models.Exam
	if err := database.DB.Preload("Questions").First(&exam, "id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Exam not found"})
		return
	}
	c.JSON(http.StatusOK, exam)
}

func SubmitAttempt(c *gin.Context) {
	var attempt models.ExamAttempt
	if err := c.ShouldBindJSON(&attempt); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	userIDStr, _ := c.Get("user_id")
	userID, _ := uuid.Parse(userIDStr.(string))
	attempt.StudentID = userID
	
	var questions []models.Question
	database.DB.Where("exam_id = ?", attempt.ExamID).Find(&questions)

	score := 0
	totalPoints := 0
	
	for _, q := range questions {
		totalPoints += q.Points
		if userAnswer, exists := attempt.Answers[q.ID.String()]; exists {
			if userAnswer == q.CorrectAnswer {
				score += q.Points
			}
		}
	}

	var exam models.Exam
	database.DB.First(&exam, "id = ?", attempt.ExamID)

	attempt.Score = score
	attempt.TotalPoints = totalPoints
	if totalPoints > 0 {
		attempt.Passed = (float64(score)/float64(totalPoints))*100 >= float64(exam.PassingScore)
	} else {
		attempt.Passed = false
	}
	
	now := time.Now()
	attempt.SubmittedAt = &now

	if err := database.DB.Create(&attempt).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, attempt)
}
